package SolverCode;
import CommonCode.ReadFile;
import CommonCode.createTile;
import CommonCode.Logic;
import java.io.FileNotFoundException;


public class main {

    public static void main(String[] args) throws FileNotFoundException {

        //setting up dictionary
        ReadFile read = new ReadFile();
        read.readFile();

        //setting up tile
        createTile crea = new createTile();
        crea.tiles();

        //setting up board
        CreateBoard board = new CreateBoard();
        board.create();

        //caling the logic to solve the puzzle
       Logic logic = new Logic(read.dictEdit, board, crea, read);
        logic.printBoard();


        logic.findPrefixfromTray();
        logic.getSuffixFromBoard();
        logic.getPrefixFromBoard();
        logic.calcScore(2,8,"lemoned");
    }
}
